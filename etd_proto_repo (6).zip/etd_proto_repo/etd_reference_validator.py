from __future__ import annotations
import json, re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import yaml

RE_NAME = re.compile(r"^etd\.[a-z0-9_]+\.[a-z0-9_]+$")
RE_VER = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+$")
RE_ENTRY = re.compile(r"^[A-Za-z0-9_./-]+:[A-Za-z0-9_]+$")
RE_PROFILE = re.compile(r"^[a-z0-9_]+$")
RE_EVENT = re.compile(r"^[a-z0-9_.-]+$")
REQUIRED = ['manifest.yaml','skill.json','chs_profiles.json','capabilities.json','execution_contract.json','telemetry/events.json','tests/acceptance_tests.yaml','policies/chs_adapter.py']
ALLOWED_FAMILY = {'pickplace','assembly','inspect','cobot','machine_tend'}
ALLOWED_TASK = {'PICK_PLACE','ASSEMBLY','INSPECTION','COBOT','MACHINE_TENDING'}
FORBIDDEN = {'command.servo_torque','command.joint_limit_override','command.collision_disable','command.emergency_stop_override','command.balance_core_override'}

@dataclass
class RuntimeContext:
    runtime_version: str
    robot_class: str
    available_services: list[str]
    platform_profile: str = 'generic'

@dataclass
class ValidationOutput:
    valid: bool
    package_path: str
    schema: dict[str,bool]
    semanticChecks: dict[str,bool]
    compatibility: dict[str,Any]
    warnings: list[str]
    errors: list[str]
    def to_json(self):
        return json.dumps(asdict(self), indent=2, ensure_ascii=False)

class ETDReferenceValidator:
    def __init__(self, runtime_context: RuntimeContext):
        self.runtime_context = runtime_context
    def _load(self, path: Path):
        if path.suffix == '.json':
            return json.loads(path.read_text(encoding='utf-8'))
        return yaml.safe_load(path.read_text(encoding='utf-8'))
    def validate_package(self, package_path: str | Path) -> ValidationOutput:
        pkg = Path(package_path)
        errors, warnings = [], []
        schema = {k: False for k in ['manifest','skill','chs_profiles','capabilities','execution_contract']}
        semantic = {'required_files_present': False,'name_matches_skill_id': False,'version_matches_skill_version': False,'default_chs_profile_exists': False,'profile_uniqueness': False,'entrypoint_exists': False,'telemetry_has_lifecycle_event': False,'capability_safe': False,'primitive_order_nonempty': False,'force_windows_valid': False,'payload_within_constraints': False}
        missing = [f for f in REQUIRED if not (pkg / f).exists()]
        if not missing: semantic['required_files_present'] = True
        else: errors += [f'missing:{m}' for m in missing]
        manifest = self._load(pkg/'manifest.yaml') if (pkg/'manifest.yaml').exists() else {}
        skill = self._load(pkg/'skill.json') if (pkg/'skill.json').exists() else {}
        chs = self._load(pkg/'chs_profiles.json') if (pkg/'chs_profiles.json').exists() else {}
        caps = self._load(pkg/'capabilities.json') if (pkg/'capabilities.json').exists() else {}
        contract = self._load(pkg/'execution_contract.json') if (pkg/'execution_contract.json').exists() else {}
        tev = self._load(pkg/'telemetry'/'events.json') if (pkg/'telemetry'/'events.json').exists() else {}
        if isinstance(manifest, dict) and manifest.get('kind')=='SkillPackage' and isinstance(manifest.get('metadata'), dict): schema['manifest'] = True
        else: errors.append('manifest_invalid')
        if isinstance(skill, dict) and RE_NAME.match(str(skill.get('skillId',''))) and RE_VER.match(str(skill.get('version',''))) and skill.get('family') in ALLOWED_FAMILY and isinstance(skill.get('primitiveOrder'), list): schema['skill'] = True
        else: errors.append('skill_invalid')
        if isinstance(chs, dict) and isinstance(chs.get('profiles'), list) and chs['profiles']: schema['chs_profiles'] = True
        else: errors.append('chs_profiles_invalid')
        if isinstance(caps, dict) and isinstance(caps.get('read'), list) and isinstance(caps.get('write'), list): schema['capabilities'] = True
        else: errors.append('capabilities_invalid')
        if isinstance(contract, dict) and all(k in contract for k in ['body_mode','arm_mode','wrist_mode','primitive','speed_profile','force_profile','timeout_sec']): schema['execution_contract'] = True
        else: errors.append('execution_contract_invalid')
        if manifest.get('metadata',{}).get('name') == skill.get('skillId'): semantic['name_matches_skill_id'] = True
        else: errors.append('name_skillid_mismatch')
        if manifest.get('metadata',{}).get('version') == skill.get('version'): semantic['version_matches_skill_version'] = True
        else: errors.append('version_mismatch')
        primitive_order = skill.get('primitiveOrder', [])
        if isinstance(primitive_order, list) and primitive_order: semantic['primitive_order_nonempty'] = True
        names = [p.get('name') for p in chs.get('profiles', []) if isinstance(p, dict)]
        if len(names)==len(set(names)) and all(RE_PROFILE.match(str(n)) for n in names): semantic['profile_uniqueness'] = True
        else: errors.append('profile_uniqueness_failed')
        if skill.get('defaultChsProfile') in names: semantic['default_chs_profile_exists'] = True
        else: errors.append('default_profile_missing')
        fw_ok = True; payload_ok = True
        max_payload = manifest.get('constraints',{}).get('payloadKgMax')
        for p in chs.get('profiles', []):
            if not isinstance(p, dict): continue
            if p.get('taskType') not in ALLOWED_TASK: fw_ok = False
            fw = p.get('forceWindowN')
            if fw is not None and (not isinstance(fw, list) or len(fw)!=2 or fw[1] < fw[0]): fw_ok = False
            if isinstance(max_payload,(int,float)) and isinstance(p.get('payloadKg'),(int,float)) and p['payloadKg'] > max_payload: payload_ok = False
        if fw_ok: semantic['force_windows_valid'] = True
        else: errors.append('force_window_invalid')
        if payload_ok: semantic['payload_within_constraints'] = True
        else: errors.append('payload_exceeds_constraints')
        entry = skill.get('entrypoint','')
        if isinstance(entry, str) and RE_ENTRY.match(entry):
            mod, _, fn = entry.partition(':')
            if (pkg/mod).exists() and fn: semantic['entrypoint_exists'] = True
            else: errors.append('entrypoint_missing')
        else: errors.append('entrypoint_invalid')
        events = set(manifest.get('telemetry',{}).get('emits',[])) | set(tev.get('events',[]))
        if events & {'skill.started','skill.completed','skill.aborted','skill.failed'}: semantic['telemetry_has_lifecycle_event'] = True
        else: errors.append('telemetry_lifecycle_missing')
        write = set(caps.get('write',[])); forbidden = set(caps.get('forbidden',[]))
        if 'command.skill_intent' in write and not (write & FORBIDDEN) and not (write & forbidden): semantic['capability_safe'] = True
        else: errors.append('capability_safety_failed')
        comp_errors, comp_warnings = [], []
        score = 1.0
        comp = manifest.get('compatibility',{}) if isinstance(manifest, dict) else {}
        if self.runtime_context.robot_class not in comp.get('robotClass',[]):
            comp_errors.append(f'robot_class_mismatch:{self.runtime_context.robot_class}')
            score -= 0.4
        for svc in comp.get('requiresServices',[]):
            if svc not in self.runtime_context.available_services:
                comp_errors.append(f'missing_required_service:{svc}')
                score -= 0.08
        for svc in comp.get('optionalServices',[]):
            if svc not in self.runtime_context.available_services:
                comp_warnings.append(f'missing_optional_service:{svc}')
                score -= 0.02
        level = 'D' if comp_errors else ('A' if score >= 0.9 and not comp_warnings else ('B' if score >= 0.8 else 'C'))
        valid = all(schema.values()) and all(semantic.values()) and not errors and level in {'A','B','C'}
        return ValidationOutput(valid, str(pkg), schema, semantic, {'level': level, 'score': round(max(0.0, score),2), 'warnings': comp_warnings, 'errors': comp_errors}, warnings, errors)

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('package')
    ap.add_argument('--runtime-context', default='runtime_context.json')
    ap.add_argument('--output', choices=['json','pretty'], default='pretty')
    args = ap.parse_args()
    ctx = json.loads(Path(args.runtime_context).read_text(encoding='utf-8'))
    report = ETDReferenceValidator(RuntimeContext(**ctx)).validate_package(args.package)
    print(report.to_json())
