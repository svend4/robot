from __future__ import annotations
import json
from pathlib import Path
from etd_reference_validator import ETDReferenceValidator, RuntimeContext

root = Path(__file__).resolve().parent
ctx = RuntimeContext(**json.loads((root/'runtime_context.json').read_text(encoding='utf-8')))
validator = ETDReferenceValidator(ctx)
print(validator.validate_package(root/'examples'/'etd.pickplace.basic').to_json())
