from __future__ import annotations
import argparse, zipfile
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('package_dir')
    ap.add_argument('output_dir')
    args = ap.parse_args()
    pkg = Path(args.package_dir).resolve()
    out = Path(args.output_dir).resolve(); out.mkdir(parents=True, exist_ok=True)
    target = out / f'{pkg.name}-0.1.0.zip'
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(pkg.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.pyc'):
                zf.write(p, arcname=f'{pkg.name}/{p.relative_to(pkg)}')
    print(target)

if __name__ == '__main__':
    main()
