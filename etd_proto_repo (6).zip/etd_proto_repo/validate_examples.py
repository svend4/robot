from __future__ import annotations
import json
from pathlib import Path
from etd_reference_validator import ETDReferenceValidator, RuntimeContext

root = Path(__file__).resolve().parent
ctx = RuntimeContext(**json.loads((root/'runtime_context.json').read_text(encoding='utf-8')))
validator = ETDReferenceValidator(ctx)
for ex in sorted((root/'examples').iterdir()):
    if ex.is_dir():
        r = validator.validate_package(ex)
        print(f'{ex.name}: valid={r.valid}, level={r.compatibility["level"]}')
