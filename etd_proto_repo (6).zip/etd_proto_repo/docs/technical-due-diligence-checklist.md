# Technical due diligence checklist

Schema, validation, compatibility, safety boundary, scenarios, release process.
