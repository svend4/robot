# Automotive use cases

Pick/place, assembly, inspection and cobot assistance on factory stations.
