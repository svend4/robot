# Roadmap v0.2

Improve schemas, adapters, simulation coverage, release automation and metrics.
