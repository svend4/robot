# Architecture

ETD is an application-layer framework above the OEM robot core.
