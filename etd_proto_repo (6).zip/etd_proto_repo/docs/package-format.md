# Package format

Required files: manifest.yaml, skill.json, chs_profiles.json, capabilities.json, execution_contract.json, telemetry/events.json, tests/acceptance_tests.yaml, policies/chs_adapter.py
