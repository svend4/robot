# Atlas integration notes

ETD should be treated as an application-layer skill framework, not as a replacement for balance, whole-body control, collision core or safety kernel.
