# Funding / pilot pitch outline

Problem, ETD abstraction, pilot scope, milestones, validation plan.
