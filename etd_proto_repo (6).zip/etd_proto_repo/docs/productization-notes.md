# Productization notes

Position ETD as a skill-package framework for industrial robots and humanoids.
