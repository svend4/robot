from __future__ import annotations

def to_enterprise_event(event_name: str, payload: dict | None = None) -> dict:
    return {'event': event_name, 'source': 'etd-runtime', 'payload': payload or {}}
