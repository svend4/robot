from __future__ import annotations

def adapt_skill_command(command: dict) -> dict:
    return {
        'accepted': True,
        'mode': 'application_layer_intent',
        'body_mode': command.get('body_mode'),
        'arm_mode': command.get('arm_mode'),
        'wrist_mode': command.get('wrist_mode'),
        'primitive': command.get('primitive'),
        'target_pose': command.get('target_pose', {}),
        'speed_profile': command.get('speed_profile'),
        'force_profile': command.get('force_profile'),
        'timeout_sec': command.get('timeout_sec'),
    }
