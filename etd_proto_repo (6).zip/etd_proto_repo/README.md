# ETD Proto Repo v0.1

Full source bundle for an ETD-based application-layer robot skill framework prototype.

## Included
- `examples/` four ETD skill packages
- `etd_reference_validator.py`
- `validate_examples.py`
- `etd_demo_runner.py`
- `scripts/release_package.py`
- `adapters/`
- `station_profiles/`
- `sim/`
- `schemas/`
- `docs/`
- `release_out/`
- `reports/`

## Quick start
```bash
pip install -r requirements.txt
python validate_examples.py
python sim/run_sim_demo.py
python sim/run_assembly_demo.py
python sim/scenario_runner.py
python sim/failure_scenarios.py
python sim/report_runner.py
```
