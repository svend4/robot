from dataclasses import dataclass
from typing import Dict, Any

@dataclass
class SkillCommand:
    body_mode: str
    arm_mode: str
    wrist_mode: str
    primitive: str
    target_pose: Dict[str, Any]
    speed_profile: str
    force_profile: str
    timeout_sec: int

def run(job_context: Dict[str, Any], robot_state: Dict[str, Any]) -> SkillCommand:
    careful = job_context.get('fragility') == 'high'
    if careful:
        return SkillCommand('micro_stable','slow_arc','minimal_force','approach_arc', job_context.get('target_pose', {'x':0.62,'y':-0.14,'z':1.08,'qx':0,'qy':0,'qz':0,'qw':1}), 'gentle','adaptive',18)
    return SkillCommand('human_aware_stable','assist_arc','soft_contact','approach_arc', job_context.get('target_pose', {'x':0.62,'y':-0.14,'z':1.08,'qx':0,'qy':0,'qz':0,'qw':1}), 'normal','adaptive',18)
