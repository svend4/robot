from __future__ import annotations
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import json
from pathlib import Path
from adapters.generic_oem_adapter import adapt_skill_command
from adapters.station_profile_loader import load_station_profile, skill_family_allowed
from sim.fake_middleware_endpoint import send_intent

root = Path(__file__).resolve().parents[1]
contract = json.loads((root/'examples'/'etd.assembly.precision'/'execution_contract.json').read_text(encoding='utf-8'))
profile = load_station_profile(root/'station_profiles'/'assembly_station_a.json')
assert skill_family_allowed(profile, 'assembly')
resp = send_intent(adapt_skill_command(contract))
assert resp['accepted']
print(json.dumps({'station_compatible': True, 'middleware_accepted': True}, indent=2))
