from __future__ import annotations
from adapters.orbit_event_bridge import to_enterprise_event

def replay_events(events: list[dict]) -> list[dict]:
    return [to_enterprise_event(e['event'], e.get('payload', {})) for e in events]
