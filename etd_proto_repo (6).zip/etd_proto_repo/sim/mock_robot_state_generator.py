from __future__ import annotations

def make_pickplace_state():
    return {'body_pose': {'payload_stable': True, 'at_target_zone': False}, 'arm_state': {'pregrasp_ready': False, 'precontact_ready': False, 'insertion_depth_reached': False}, 'wrist_state': {'object_secured': False, 'contact_model_established': False, 'alignment_verified': False}, 'object_pose': {'x': 0.4, 'y': 0.1, 'z': 0.8}, 'part_pose': {'x': 0.4, 'y': 0.1, 'z': 0.8}, 'target_pose': {'x': 0.6, 'y': -0.1, 'z': 1.0}, 'safety_state': {'human_too_close': False}}

def make_assembly_state():
    return make_pickplace_state()
