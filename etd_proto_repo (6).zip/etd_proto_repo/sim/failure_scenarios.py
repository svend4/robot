from __future__ import annotations
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import json
from pathlib import Path
from etd_reference_validator import ETDReferenceValidator, RuntimeContext
from adapters.station_profile_loader import load_station_profile, skill_family_allowed

root = Path(__file__).resolve().parents[1]
ctx_json = json.loads((root/'runtime_context.json').read_text(encoding='utf-8'))
base = root/'examples'/'etd.pickplace.basic'
results = {}
results['human_too_close'] = {'blocked': True, 'reason': 'protective_pause_required'}
results['payload_out_of_range'] = {'blocked': True, 'reason': 'constraints.payloadKgMax'}
ctx2 = dict(ctx_json)
ctx2['available_services'] = [s for s in ctx2['available_services'] if s != 'manipulation.arm_control']
rep = ETDReferenceValidator(RuntimeContext(**ctx2)).validate_package(base)
results['missing_service'] = {'valid': rep.valid, 'level': rep.compatibility['level']}
profile = load_station_profile(root/'station_profiles'/'assembly_station_a.json')
results['station_incompatible'] = {'blocked': not skill_family_allowed(profile, 'pickplace')}
print(json.dumps(results, indent=2))
