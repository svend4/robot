from __future__ import annotations
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import json
import subprocess

root = ROOT
py = sys.executable


def run(cmd: list[str]) -> str:
    return subprocess.check_output([py, *cmd], cwd=root, text=True)


validation = []
for pkg in sorted((root / 'examples').iterdir()):
    if pkg.is_dir():
        data = json.loads(run(['etd_reference_validator.py', str(pkg), '--runtime-context', 'runtime_context.json', '--output', 'json']))
        validation.append({'package': pkg.name, 'valid': data['valid'], 'level': data['compatibility']['level']})

scenario_summary = json.loads(run(['sim/scenario_runner.py']))
failure_summary = json.loads(run(['sim/failure_scenarios.py']))
release_dir = root / 'release_out'
release_summary = {'artifacts': sorted([p.name for p in release_dir.glob('*.zip')])}
overall_pass = all(v['valid'] and v['level'] == 'A' for v in validation)
report = {
    'overall_pass': overall_pass,
    'validation_summary': validation,
    'scenario_summary': scenario_summary,
    'failure_summary': failure_summary,
    'release_summary': release_summary,
}
(root / 'reports').mkdir(exist_ok=True)
(root / 'reports' / 'report_summary.json').write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
md_lines = ['# Report summary', '', f'overall_pass: {overall_pass}', '', '## validation']
for v in validation:
    md_lines.append(f"- {v['package']}: valid={v['valid']}, level={v['level']}")
(root / 'reports' / 'report_summary.md').write_text('\n'.join(md_lines) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2, ensure_ascii=False))
