from __future__ import annotations
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import json
from pathlib import Path
from etd_reference_validator import ETDReferenceValidator, RuntimeContext

root = Path(__file__).resolve().parents[1]
ctx = RuntimeContext(**json.loads((root/'runtime_context.json').read_text(encoding='utf-8')))
validator = ETDReferenceValidator(ctx)
results = []
for pkg in sorted((root/'examples').iterdir()):
    if pkg.is_dir():
        rep = validator.validate_package(pkg)
        results.append({'package': pkg.name, 'valid': rep.valid, 'level': rep.compatibility['level']})
print(json.dumps({'scenarios': results}, indent=2))
