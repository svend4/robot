from __future__ import annotations

def send_intent(request: dict) -> dict:
    return {'accepted': bool(request.get('primitive')), 'request_echo': request}
