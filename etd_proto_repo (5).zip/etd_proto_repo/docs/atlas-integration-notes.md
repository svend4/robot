# Atlas / OEM Integration Notes

Use ETD above OEM middleware only. The OEM platform remains responsible for balance, locomotion, contact safety and certified protective behavior.
