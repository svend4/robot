# Architecture

ETD is positioned as an application-layer runtime above OEM robot core. The runtime validates skill packages, routes CHS task context, emits telemetry and blocks unsafe capabilities.
