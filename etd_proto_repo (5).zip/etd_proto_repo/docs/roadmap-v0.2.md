# Roadmap v0.2

- Hardening validator.
- Package signing.
- Richer schemas.
- Better simulator.
- CI integration.
- Marketplace governance.
