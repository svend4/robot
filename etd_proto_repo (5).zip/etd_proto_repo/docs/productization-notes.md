# Productization Notes

Position ETD as a skill authoring and validation layer, not as a replacement for robot OS or OEM motion-control software.
