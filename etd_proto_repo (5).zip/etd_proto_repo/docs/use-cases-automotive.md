# Automotive Use Cases

Potential factory tasks include sequencing, pick-and-place, machine tending, inspection, precision assembly and cobot assistance.
