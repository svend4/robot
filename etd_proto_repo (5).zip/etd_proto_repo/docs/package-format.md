# Package Format

A package includes `manifest.yaml`, `skill.json`, `chs_profiles.json`, `capabilities.json`, `execution_contract.json`, telemetry declarations, tests and a policy entrypoint.
