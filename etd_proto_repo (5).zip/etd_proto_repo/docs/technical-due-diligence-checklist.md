# Technical Due Diligence Checklist

- Validate capability policy.
- Confirm no safety-core override.
- Verify simulator scenarios.
- Run failure scenarios.
- Confirm package signing path.
