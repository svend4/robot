# ETD Robot Skill Runtime Prototype

`etd_proto_repo` is a proof-of-concept application-layer framework for robot skill packages inspired by the ETD / Kryukov movement model.

The project treats robot abilities as installable, validated skill packages rather than unsafe low-level firmware modules. It is designed for humanoid / industrial robots where the OEM core remains responsible for balance, low-level control, collision safety and protective stops.

## What is inside

- `examples/` — four reference skill packages
- `schemas/` — draft machine-readable package schemas
- `etd_reference_validator.py` — package validation and compatibility scoring
- `scripts/release_package.py` — release package builder
- `adapters/` — OEM and enterprise bridge examples
- `station_profiles/` — workcell compatibility examples
- `sim/` — sandbox demos, scenarios, failure paths and reporting
- `marketplace/` — ETD skill store index and policy layer
- `docs/` — architecture, integration, productization and funding notes

## Quick start

```bash
pip install -r requirements.txt
python validate_examples.py
python marketplace/skill_store.py validate
python sim/marketplace_demo.py
python sim/report_runner.py
```

## Design rule

ETD packages return high-level skill intents. They must not request servo torque, safety override, collision-disable or balance-core override capabilities.
