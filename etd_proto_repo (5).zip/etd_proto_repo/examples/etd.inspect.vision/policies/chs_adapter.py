from dataclasses import dataclass
from typing import Dict, Any
@dataclass
class SkillCommand:
    body_mode: str; arm_mode: str; wrist_mode: str; primitive: str; target_pose: Dict[str, Any]; speed_profile: str; force_profile: str; timeout_sec: int
def run(job_context: Dict[str, Any], robot_state: Any) -> SkillCommand:
    return SkillCommand('stable_scan','vision_arc','camera_hold','scan_capture',job_context.get('target_pose',{'x':0.5,'y':0,'z':1.2,'qx':0,'qy':0,'qz':0,'qw':1}),'slow_scan','none',20)
