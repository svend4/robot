from dataclasses import dataclass
from typing import Dict, Any
@dataclass
class SkillCommand:
    body_mode: str; arm_mode: str; wrist_mode: str; primitive: str; target_pose: Dict[str, Any]; speed_profile: str; force_profile: str; timeout_sec: int
def run(job_context: Dict[str, Any], robot_state: Any) -> SkillCommand:
    return SkillCommand('human_aware_stance','handover_arc','soft_handover','assist_handover',job_context.get('target_pose',{'x':0.3,'y':0.2,'z':1.0,'qx':0,'qy':0,'qz':0,'qw':1}),'human_safe','minimal',30)
