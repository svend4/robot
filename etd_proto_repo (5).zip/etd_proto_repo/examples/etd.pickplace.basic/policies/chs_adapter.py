from dataclasses import dataclass
from typing import Dict, Any
@dataclass
class SkillCommand:
    body_mode: str; arm_mode: str; wrist_mode: str; primitive: str; target_pose: Dict[str, Any]; speed_profile: str; force_profile: str; timeout_sec: int
def run(job_context: Dict[str, Any], robot_state: Any) -> SkillCommand:
    fragile = job_context.get('fragility') == 'high'
    return SkillCommand('micro_stable' if fragile else 'stable_reach','slow_arc' if fragile else 'guarded_arc','minimal_force' if fragile else 'adaptive_contact','approach_arc',job_context.get('target_pose',{'x':0.6,'y':0,'z':1.0,'qx':0,'qy':0,'qz':0,'qw':1}),'gentle' if fragile else 'normal','adaptive',18)
