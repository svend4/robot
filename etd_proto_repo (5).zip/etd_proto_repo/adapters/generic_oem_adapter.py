from dataclasses import dataclass, asdict
from typing import Dict, Any
@dataclass
class OEMRequest:
    request_type: str
    payload: Dict[str, Any]
    safety_scope: str = 'application_layer_only'
def to_oem_request(skill_command: Dict[str, Any]) -> Dict[str, Any]:
    allowed={k:skill_command[k] for k in ['body_mode','arm_mode','wrist_mode','primitive','target_pose','speed_profile','force_profile','timeout_sec'] if k in skill_command}
    return asdict(OEMRequest('skill_intent', allowed))
