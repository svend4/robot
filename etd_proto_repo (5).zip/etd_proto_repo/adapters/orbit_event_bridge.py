from typing import Dict, Any
def to_enterprise_event(event: Dict[str, Any]) -> Dict[str, Any]:
    return {'source':'etd-runtime','event_type':event.get('type','unknown'),'skill_id':event.get('skill_id'),'timestamp':event.get('timestamp'),'payload':event.get('payload',{})}
