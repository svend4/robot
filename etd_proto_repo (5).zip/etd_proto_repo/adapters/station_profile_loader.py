import json
from pathlib import Path
def load_station_profile(path): return json.loads(Path(path).read_text())
def is_skill_allowed(station, family): return family in station.get('allowedSkillFamilies', [])
