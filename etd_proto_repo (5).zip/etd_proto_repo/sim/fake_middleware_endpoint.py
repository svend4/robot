def send_oem_request(req):
    forbidden = req.get('payload',{}).get('primitive','').startswith('fallback:forbidden')
    return {'accepted': not forbidden, 'status':'accepted' if not forbidden else 'rejected'}
