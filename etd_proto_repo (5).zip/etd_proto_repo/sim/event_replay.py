from adapters.orbit_event_bridge import to_enterprise_event
def replay(events): return [to_enterprise_event(e) for e in events]
