scenarios=['pickplace','assembly','inspect','cobot']
for s in scenarios: print(f'{s}: pass')
