import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from marketplace.skill_store import validate_store
print(json.dumps({'marketplace_validation': validate_store(Path(__file__).resolve().parents[1])}, indent=2))
