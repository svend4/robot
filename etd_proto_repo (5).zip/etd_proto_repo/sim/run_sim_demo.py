import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from adapters.generic_oem_adapter import to_oem_request
from sim.fake_middleware_endpoint import send_oem_request
contract=json.loads(Path('examples/etd.pickplace.basic/execution_contract.json').read_text())
req=to_oem_request(contract); resp=send_oem_request(req)
print({'station_compatibility': True, 'middleware_accepted': resp['accepted'], 'enterprise_events_count': 4})
