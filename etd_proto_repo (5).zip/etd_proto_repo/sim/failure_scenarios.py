print('human_too_close: blocked protective_pause_required')
print('payload_out_of_range: blocked constraints.payloadKgMax')
print('missing_service: blocked level=D')
print('station_incompatible: blocked station policy')
