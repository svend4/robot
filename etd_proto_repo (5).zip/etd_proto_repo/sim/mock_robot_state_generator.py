def mock_state(family='pickplace', human_too_close=False):
    return {'body_pose':{'stable':True},'arm_state':{'ready':True},'wrist_state':{'ready':True},'object_pose':{'known':True},'target_pose':{'known':True},'safety_state':{'human_too_close':human_too_close}}
