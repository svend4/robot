from __future__ import annotations
import json, re, argparse
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, List, Optional
import yaml

NAME_RE = re.compile(r"^etd\.[a-z0-9_]+\.[a-z0-9_]+$")
VERSION_RE = re.compile(r"^\d+\.\d+\.\d+$")
API_RE = re.compile(r"^etd\.robotics/v\d+\.\d+$")
ALLOWED_CLASSES = {'humanoid','mobile_manipulator','fixed_manipulator','dual_arm_system'}
ALLOWED_FAMILIES = {'pickplace','assembly','inspect','cobot','machine_tend'}
FORBIDDEN_WRITES = {'command.servo_torque','command.joint_limit_override','command.collision_disable','command.emergency_stop_override','command.balance_core_override'}
REQUIRED_FILES = ['manifest.yaml','skill.json','chs_profiles.json','capabilities.json','execution_contract.json','telemetry/events.json','tests/acceptance_tests.yaml']

@dataclass
class RuntimeContext:
    runtime_version: str
    robot_class: str
    available_services: List[str]
    platform_profile: str = 'generic'

@dataclass
class ValidationMessage:
    code: str
    message: str
    path: Optional[str]=None

@dataclass
class Compatibility:
    level: str='D'
    score: float=0.0
    warnings: List[str]=field(default_factory=list)
    errors: List[str]=field(default_factory=list)

@dataclass
class ValidationOutput:
    valid: bool
    package_path: str
    schema: Dict[str,bool]
    semantic_checks: Dict[str,bool]
    compatibility: Compatibility
    warnings: List[ValidationMessage]=field(default_factory=list)
    errors: List[ValidationMessage]=field(default_factory=list)
    def to_dict(self):
        d=asdict(self); d['compatibility']=asdict(self.compatibility); return d
    def to_json(self):
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)

class ETDReferenceValidator:
    def __init__(self, runtime_context: RuntimeContext):
        self.ctx = runtime_context
    def _load(self, p: Path):
        if p.suffix in {'.yaml','.yml'}:
            return yaml.safe_load(p.read_text(encoding='utf-8'))
        return json.loads(p.read_text(encoding='utf-8'))
    def validate_package(self, package_path: str|Path) -> ValidationOutput:
        p = Path(package_path)
        errors: List[ValidationMessage] = []
        warnings: List[ValidationMessage] = []
        schema = {k: False for k in ['manifest','skill','chs_profiles','capabilities','execution_contract']}
        sem = {k: False for k in ['required_files_present','name_matches_skill_id','version_matches_skill_version','default_chs_profile_exists','profile_uniqueness','entrypoint_exists','telemetry_has_lifecycle_event','capability_safe','primitive_order_nonempty','force_windows_valid','payload_within_constraints']}
        missing = [f for f in REQUIRED_FILES if not (p/f).exists()]
        if missing:
            for f in missing: errors.append(ValidationMessage('required_file_missing', f'Missing {f}', f))
        else:
            sem['required_files_present']=True
        try:
            m=self._load(p/'manifest.yaml'); s=self._load(p/'skill.json'); c=self._load(p/'chs_profiles.json'); caps=self._load(p/'capabilities.json'); ec=self._load(p/'execution_contract.json'); te=self._load(p/'telemetry/events.json')
        except Exception as e:
            errors.append(ValidationMessage('parse_error', str(e)))
            return ValidationOutput(False,str(p),schema,sem,Compatibility(errors=['parse_error']),warnings,errors)
        schema['manifest']=self._check_manifest(m, errors)
        schema['skill']=self._check_skill(s, errors)
        schema['chs_profiles']=self._check_chs(c, errors)
        schema['capabilities']=self._check_caps(caps, errors)
        schema['execution_contract']=self._check_exec(ec, errors)
        sem['name_matches_skill_id'] = m.get('metadata',{}).get('name') == s.get('skillId')
        sem['version_matches_skill_version'] = m.get('metadata',{}).get('version') == s.get('version')
        profiles = [x.get('name') for x in c.get('profiles',[]) if isinstance(x,dict)]
        sem['default_chs_profile_exists'] = s.get('defaultChsProfile') in profiles
        sem['profile_uniqueness'] = len(profiles)==len(set(profiles))
        sem['entrypoint_exists'] = (p / s.get('entrypoint','').split(':')[0]).exists()
        events = set(m.get('telemetry',{}).get('emits',[])) | set(te.get('events',[]))
        sem['telemetry_has_lifecycle_event'] = bool(events & {'skill.started','skill.completed','skill.aborted','skill.failed'})
        writes = set(caps.get('write',[])); forb=set(caps.get('forbidden',[]))
        sem['capability_safe'] = 'command.skill_intent' in writes and not (writes & FORBIDDEN_WRITES) and not (writes & forb)
        sem['primitive_order_nonempty'] = isinstance(s.get('primitiveOrder'),list) and len(s['primitiveOrder'])>0
        sem['force_windows_valid'] = all((not isinstance(x,dict) or 'forceWindowN' not in x or (isinstance(x['forceWindowN'],list) and len(x['forceWindowN'])==2 and x['forceWindowN'][1]>=x['forceWindowN'][0])) for x in c.get('profiles',[]))
        max_payload = m.get('constraints',{}).get('payloadKgMax')
        sem['payload_within_constraints'] = True if max_payload is None else all((not isinstance(x,dict) or 'payloadKg' not in x or x['payloadKg']<=max_payload) for x in c.get('profiles',[]))
        for k,v in sem.items():
            if not v: errors.append(ValidationMessage('semantic_failed', f'{k} failed'))
        comp = self._compat(m, caps)
        valid = all(schema.values()) and all(sem.values()) and not errors and comp.level in {'A','B','C'}
        return ValidationOutput(valid,str(p),schema,sem,comp,warnings,errors)
    def _check_manifest(self,m,e):
        ok=True
        if not API_RE.match(str(m.get('apiVersion',''))): ok=False; e.append(ValidationMessage('manifest_api_invalid','bad apiVersion'))
        if m.get('kind')!='SkillPackage': ok=False; e.append(ValidationMessage('manifest_kind_invalid','kind must be SkillPackage'))
        md=m.get('metadata',{})
        if not NAME_RE.match(str(md.get('name',''))): ok=False; e.append(ValidationMessage('manifest_name_invalid','bad metadata.name'))
        if not VERSION_RE.match(str(md.get('version',''))): ok=False; e.append(ValidationMessage('manifest_version_invalid','bad metadata.version'))
        co=m.get('compatibility',{})
        if co.get('osLayer')!='application': ok=False; e.append(ValidationMessage('manifest_oslayer_invalid','osLayer must be application'))
        if not set(co.get('robotClass',[])) <= ALLOWED_CLASSES or not co.get('robotClass'): ok=False; e.append(ValidationMessage('manifest_robotclass_invalid','bad robotClass'))
        if not co.get('requiresServices'): ok=False; e.append(ValidationMessage('manifest_requires_invalid','requiresServices empty'))
        if not m.get('execution',{}).get('defaultTimeoutSec'): ok=False; e.append(ValidationMessage('manifest_execution_invalid','missing defaultTimeoutSec'))
        if not m.get('telemetry',{}).get('emits'): ok=False; e.append(ValidationMessage('manifest_telemetry_invalid','missing emits'))
        return ok
    def _check_skill(self,s,e):
        ok=True
        if not NAME_RE.match(str(s.get('skillId',''))): ok=False; e.append(ValidationMessage('skill_id_invalid','bad skillId'))
        if not VERSION_RE.match(str(s.get('version',''))): ok=False; e.append(ValidationMessage('skill_version_invalid','bad version'))
        if ':' not in str(s.get('entrypoint','')): ok=False; e.append(ValidationMessage('skill_entrypoint_invalid','bad entrypoint'))
        if s.get('family') not in ALLOWED_FAMILIES: ok=False; e.append(ValidationMessage('skill_family_invalid','bad family'))
        if not s.get('primitiveOrder'): ok=False; e.append(ValidationMessage('skill_primitive_order_invalid','empty primitiveOrder'))
        if not isinstance(s.get('successCriteria'),dict) or not s.get('successCriteria'): ok=False; e.append(ValidationMessage('skill_success_invalid','bad successCriteria'))
        return ok
    def _check_chs(self,c,e):
        ok=isinstance(c.get('profiles'),list) and len(c.get('profiles'))>0
        if not ok: e.append(ValidationMessage('chs_profiles_invalid','profiles missing'))
        for x in c.get('profiles',[]):
            if 'name' not in x or 'taskType' not in x: ok=False; e.append(ValidationMessage('chs_profile_invalid','missing name/taskType'))
        return ok
    def _check_caps(self,c,e):
        ok = isinstance(c.get('read'),list) and isinstance(c.get('write'),list)
        if not ok: e.append(ValidationMessage('caps_invalid','read/write required'))
        if set(c.get('write',[])) & FORBIDDEN_WRITES: ok=False; e.append(ValidationMessage('caps_forbidden_write','forbidden write requested'))
        return ok
    def _check_exec(self,c,e):
        ok=all(isinstance(c.get(k),str) and c.get(k) for k in ['body_mode','arm_mode','wrist_mode','primitive','speed_profile','force_profile']) and isinstance(c.get('timeout_sec'),(int,float)) and 1<=c.get('timeout_sec')<=300
        if not ok: e.append(ValidationMessage('exec_contract_invalid','bad execution contract'))
        return ok
    def _compat(self,m,caps):
        co=m.get('compatibility',{})
        score=1.0; ce=[]; cw=[]
        if self.ctx.robot_class not in co.get('robotClass',[]): ce.append('robot class mismatch'); score-=0.45
        avail=set(self.ctx.available_services)
        missing=[x for x in co.get('requiresServices',[]) if x not in avail]
        if missing: ce += [f'missing required service: {x}' for x in missing]; score-=min(0.5,0.08*len(missing))
        missing_opt=[x for x in co.get('optionalServices',[]) if x not in avail]
        if missing_opt: cw += [f'missing optional service: {x}' for x in missing_opt]; score-=min(0.12,0.02*len(missing_opt))
        if set(caps.get('write',[])) & FORBIDDEN_WRITES: ce.append('forbidden write capability'); score-=0.5
        score=max(0,min(1,score))
        level='D' if ce else ('B' if cw else 'A')
        return Compatibility(level, round(score,2), cw, ce)

def load_runtime_context(path):
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    return RuntimeContext(**data)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('package')
    ap.add_argument('--runtime-context', default='runtime_context.json')
    ap.add_argument('--output', choices=['pretty','json'], default='pretty')
    args=ap.parse_args()
    ctx=load_runtime_context(args.runtime_context) if Path(args.runtime_context).exists() else RuntimeContext('0.1.0','humanoid',[])
    out=ETDReferenceValidator(ctx).validate_package(args.package)
    if args.output=='json': print(out.to_json()); return
    print(f'valid={out.valid} level={out.compatibility.level} score={out.compatibility.score}')
    if out.errors:
        print('errors:')
        for e in out.errors: print(f'- {e.code}: {e.message}')
if __name__=='__main__': main()
