# Changelog

## v0.1.0

- Initial ETD runtime prototype.
- Four example skill packages.
- Marketplace / skill-store layer added after Unitree app-store signal.
