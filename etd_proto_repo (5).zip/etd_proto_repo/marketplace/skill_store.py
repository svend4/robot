from __future__ import annotations
import json, argparse, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from etd_reference_validator import ETDReferenceValidator, RuntimeContext

def load_index(root: Path): return json.loads((root/'marketplace/skill_store_index.json').read_text())
def list_skills(root: Path): return load_index(root)['entries']
def validate_store(root: Path):
    ctx=RuntimeContext(**json.loads((root/'runtime_context.json').read_text()))
    v=ETDReferenceValidator(ctx); out=[]
    for e in list_skills(root):
        r=v.validate_package(root/e['packagePath'])
        out.append({'skillId':e['skillId'],'valid':r.valid,'level':r.compatibility.level,'score':r.compatibility.score})
    return out
def main():
    root=Path(__file__).resolve().parents[1]
    ap=argparse.ArgumentParser(); ap.add_argument('cmd', choices=['list','validate'])
    args=ap.parse_args()
    print(json.dumps(list_skills(root) if args.cmd=='list' else validate_store(root), indent=2, ensure_ascii=False))
if __name__=='__main__': main()
