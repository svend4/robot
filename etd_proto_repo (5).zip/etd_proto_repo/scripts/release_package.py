from pathlib import Path
import argparse, zipfile, json, sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from etd_reference_validator import ETDReferenceValidator, RuntimeContext

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('package'); ap.add_argument('--out', default='release_out'); args=ap.parse_args()
    root=Path(__file__).resolve().parents[1]; pkg=Path(args.package)
    if not pkg.is_absolute(): pkg=root/pkg
    ctx=RuntimeContext(**json.loads((root/'runtime_context.json').read_text()))
    rep=ETDReferenceValidator(ctx).validate_package(pkg)
    if not rep.valid: print(rep.to_json()); raise SystemExit(1)
    skill=json.loads((pkg/'skill.json').read_text())
    outdir=root/args.out; outdir.mkdir(exist_ok=True)
    out=outdir/f"{skill['skillId']}-{skill['version']}.zip"
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for f in pkg.rglob('*'):
            if f.is_file() and '__pycache__' not in str(f): z.write(f, f.relative_to(pkg))
    print(out)
if __name__=='__main__': main()
