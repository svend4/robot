from pathlib import Path
import json
from etd_reference_validator import ETDReferenceValidator, RuntimeContext
ctx = RuntimeContext(**json.loads(Path('runtime_context.json').read_text()))
validator = ETDReferenceValidator(ctx)
all_ok=True
for p in sorted(Path('examples').iterdir()):
    if not p.is_dir(): continue
    r=validator.validate_package(p)
    print(f'{p.name}: valid={r.valid} level={r.compatibility.level} score={r.compatibility.score}')
    all_ok = all_ok and r.valid
raise SystemExit(0 if all_ok else 1)
