# ETD Robotics Skill Runtime Prototype

This repository is a proof-of-concept for an **application-layer robot skill package framework** inspired by the ETD / Kryukov movement-theory work. It is designed as a skill-runtime, package-validation, marketplace, and integration layer above OEM robot control stacks, not as a replacement for certified robot core software.

## What is included

- ETD skill packages: `pickplace`, `assembly`, `inspect`, `cobot`
- Package validator and schemas
- Release tooling
- Integration adapters
- Station profiles
- Simulation/sandbox scripts
- Marketplace index and commercial policy draft
- Automotive, Atlas-style, Unitree-style, and productization notes

## Quick start

```bash
pip install -r requirements.txt
python validate_examples.py
python sim/run_sim_demo.py
python sim/run_assembly_demo.py
python sim/scenario_runner.py
python sim/failure_scenarios.py
python sim/report_runner.py
python sim/marketplace_demo.py
```

## Key idea

ETD packages should only emit safe high-level skill intents. They must not override locomotion, servo torque, collision, emergency stop, balance, or human-protective-stop logic.

## Documentation highlights

- `docs/documentation-expansion-guide.md` — how to turn this PoC into a complete technical handbook.
- `docs/licensing-and-commercialization.md` — open-source, free, paid, and enterprise-private skill models.
- `docs/marketplace-commercial-policy.md` — marketplace licensing, entitlement, and package-protection policy.
- `docs/marketplace-architecture.md` — ETD skill store architecture.
- `docs/unitree-skill-marketplace-analysis.md` — public Unitree skill-store context and positioning.
- `docs/atlas-integration-notes.md` — notes on OEM-style humanoid integration boundaries.

## Marketplace model

The prototype now supports a mixed marketplace model:

- open-source reference packages;
- free binary/demo packages;
- commercial paid packages;
- enterprise-private packages;
- dataset/model packages.

A package may be open-source or closed-source, free or paid, but every executable package should be signed, validated, capability-limited, and station-approved before activation.
